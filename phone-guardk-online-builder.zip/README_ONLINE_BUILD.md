# Gibson Guard — phone-only APK build (repository: phone-guardk)

This project is prepared for building an Android APK remotely with GitHub Actions. You do **not** need Android Studio on your phone or computer.

## Build from your phone

1. Create a GitHub account at https://github.com/ if you do not already have one.
2. Create a new repository, for example `GibsonGuard`.
3. Upload the **contents of this GibsonGuard folder** (not the outer ZIP folder) to the repository.
4. Open the repository's **Actions** tab.
5. Select **Build Gibson Guard APK** in the `phone-guardk` repository.
6. Tap **Run workflow**.
7. Wait for the green check mark.
8. Open the completed workflow run and download the **GibsonGuard-debug-apk** artifact.
9. Extract the artifact ZIP and install `app-debug.apk` on your Android phone.

## Important

- The debug APK is suitable for personal testing and installation.
- A release APK for public distribution should use your own signing key.
- The security key is stored locally by the app. The default key in this project is `GUARD-2026`; change it immediately after installation.
- Gibson Guard does not secretly monitor, control, or upload phone data.
